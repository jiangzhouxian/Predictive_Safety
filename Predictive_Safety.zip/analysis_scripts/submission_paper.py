"""Build the evidence-linked submission revision without changing earlier drafts."""
from pathlib import Path
import json
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .submission_evidence import ROOT,read,KINDS

PAPER=Path('paper_revision_20260917_submission')
SOURCE=Path('paper_revision_20260917_theory')
NAMES=['Geometric','Adaptive','NN-Adaptive']

def write(name,text): (PAPER/name).write_text(text,encoding='utf-8')
def table(name,caption,label,header,rows,cols):
    compact=[r'\setlength{\tabcolsep}{3pt}'] if name in ['data_partitions.tex','training_ablations.tex'] else []
    write(name,'\n'.join([r'\begin{table}[!htbp]',r'\centering\small',r'\caption{'+caption+'}',r'\label{'+label+'}',*compact,r'\begin{tabular}{'+cols+'}',r'\toprule',header+r' \\',r'\midrule',*[' & '.join(row)+r' \\' for row in rows],r'\bottomrule',r'\end{tabular}',r'\end{table}'])+'\n')

def assets(stats):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'pdf.fonttype':42})
    colors=['#2d658a','#d08432','#188675']
    fig,ax=plt.subplots(2,2,figsize=(9,6.7),layout='constrained')
    for kind,name,color in zip(KINDS,NAMES,colors):
        v=stats['controllers'][kind];e=v['events'];bins=v['reliability'];quart=v['spread_quartiles']
        ax[0,0].plot([b['mean_p'] for b in bins],[b['rate'] for b in bins],'o-',color=color,label=name)
        ax[0,1].plot(np.arange(1,5),[q['rmse'] for q in quart],'o-',color=color,label=name)
        leads=np.sort([t for row in e['records'] for t in row['lead_s']])
        ax[1,0].step(leads,np.arange(1,len(leads)+1)/len(leads),where='post',color=color,label=name)
        ax[1,1].step(leads-e['latency_proxy_s'],np.arange(1,len(leads)+1)/len(leads),where='post',color=color,label=name)
    ax[0,0].plot([0,1],[0,1],':',color='gray');ax[0,0].set(xlabel='Mean predicted violation probability',ylabel='Observed violation frequency',title='(a) Held-out probability reliability',xlim=(0,1),ylim=(0,1))
    ax[0,1].set(xlabel='Ensemble-spread quartile (low to high)',ylabel='Endpoint RMSE (m)',title='(b) Disagreement identifies harder forecasts',xticks=[1,2,3,4])
    ax[1,0].set(xlabel='Pre-violation interval (s)',ylabel='Cumulative fraction of detected events',title='(c) Event-level warning timing',xlim=(0,1),ylim=(0,1))
    ax[1,1].axvline(0,color='gray',ls=':');ax[1,1].set(xlabel='Interval minus rollout latency proxy (s)',ylabel='Cumulative fraction of detected events',title='(d) Timing after diagnostic cost deduction',ylim=(0,1))
    for a in ax.flat:a.grid(alpha=.2);a.spines[['right','top']].set_visible(False)
    ax[0,0].legend(loc='upper left',fontsize=8,frameon=False)
    fig.savefig(PAPER/'reliability_events.pdf');fig.savefig(PAPER/'reliability_events.png',dpi=170);plt.close(fig)
    rows=[]
    for kind,name in zip(KINDS,NAMES):
        for metric in ['RMSE_m','Brier','Recall','FPR']:
            v=stats['controllers'][kind]['paired_latest'][metric]
            rows.append([name,{'RMSE_m':'RMSE (m)','Brier':'Brier','Recall':'Recall','FPR':'FPR'}[metric],f"{v['difference']:+.4f}",f"[{v['CI95'][0]:+.4f}, {v['CI95'][1]:+.4f}]"])
    table('paired_statistics.tex',r'Paired differences (CIL world model minus Latest residual) and 95\% episode-bootstrap intervals. Negative values favor CIL for RMSE, Brier, and FPR; positive values favor CIL for recall. Intervals are conditional on the sampled scenarios, not independent-seed generalization guarantees.','tab:paired','Controller & Metric & Difference & 95\% interval',rows,'llrr')
    rows=[]
    for kind,name in zip(KINDS,NAMES):
        e=stats['controllers'][kind]['events'];rows.append([name,str(e['total_onsets']),str(e['eligible']),str(e['detected']),f"{e['recall']:.3f}",f"{e['lead_quantiles_s'][1]:.3f}",f"{e['false_runs_per_minute']:.2f}"])
    table('event_statistics.tex',r'Event-level warning evidence at the recorded 1-Hz evaluation schedule. All: unsafe onsets in the observation interval; eligible: onsets with a safe preceding prediction anchor; detected: eligible onsets warned before crossing. Lead is the median among detected events, not the prediction horizon. FAR counts false-alarm runs per observed minute.','tab:events','Controller & All & Eligible & Detected & Recall & Lead (s) & FAR',rows,'lrrrrrr')
    rows=[]
    for kind,name in zip(KINDS,NAMES):
        v=stats['controllers'][kind];rows.append([name,str(v['anchors']),str(v['positives']),f"{v['prevalence']:.3f}",f"{v['ECE']:.3f}",f"{v['spread_error_spearman']:.3f}"])
    table('reliability_statistics.tex',r'Probability and uncertainty diagnostics. Prevalence and ECE use currently safe anchors; descriptive Spearman correlation uses ensemble spread and position error over all 3,360 anchors per controller. Temporal dependence precludes treating anchors as independent trials.','tab:reliability','Controller & Safe anchors & Positive & Prevalence & ECE & Correlation',rows,'lrrrrr')
    rows=[]
    for kind,name in zip(KINDS,NAMES):
        for g,v in stats['controllers'][kind]['strata'].items():rows.append([name,g.replace('_',' '),str(v['episodes']),f"{v['episode_coverage']:.3f}",f"{v['diameter_m']:.3f}"])
    table('uncertainty_strata.tex',r'Proposed-method position sets by disturbance group at 90\% nominal episode coverage. Ground effect includes combined wind cases; other groups contain no imposed ground effect. These are subgroup diagnostics, not separately calibrated guarantees.','tab:strata','Controller & Group & Flights & Coverage & Diameter (m)',rows,'llrrr')
    rows=read(ROOT/'training_ablations.json')
    wm=next(r for r in read('artifacts/three_controller_paper_20260916/report.json')['prediction']['nn_adaptive_v2'] if r['method']=='world_model' and r['horizon_s']==1)
    rows.append({'name':'History / multi-step (Ours)','RMSE_m':wm['position_RMSE_m'],'AP':wm['AP'],'Brier':wm['Brier'],'Recall':wm['Recall'] if 'Recall' in wm else wm['recall'],'FPR':wm['FPR'] if 'FPR' in wm else wm['fpr']})
    fields=['RMSE_m','AP','Brier','Recall','FPR'];best={k:(max if k in ['AP','Recall'] else min)(round(r[k],3) for r in rows) for k in fields}
    display=[]
    for r in rows:
        display.append([r['name']]+[(r'\textbf{'+f'{r[k]:.3f}'+'}') if round(r[k],3)==best[k] else f'{r[k]:.3f}' for k in fields])
    table('training_ablations.tex',r'Additional training ablations on the same 60 NN-Adaptive confirmation flights. All variants use three members and identical controller-in-the-loop inference. Bold identifies the best displayed value (ties included); recall and FPR must be read jointly.','tab:training_ablations',r'Training variant & RMSE $\downarrow$ & AUPRC $\uparrow$ & Brier $\downarrow$ & Recall $\uparrow$ & FPR $\downarrow$',display,'lrrrrr')

MATH=r'''
\paragraph{Nominal command-response model}
In NED coordinates, let $R(\mathbf q)$ map body vectors to the inertial frame, $\mathbf e_3=[0,0,1]^\top$, and $\mathbf u=(\phi_c,\theta_c,\psi_c,T_c)$. The nominal equations are
\begin{align}
\dot{\mathbf p}&=\mathbf v, &
\dot{\mathbf v}&=g\mathbf e_3-b(T_c)R(\mathbf q)\mathbf e_3+\mathbf a_v^{\rm res},\\
\dot{\mathbf q}&=\tfrac12\mathbf q\otimes[0,\boldsymbol\omega], &
\dot{\boldsymbol\omega}&=-K_R\mathbf e_R-K_\omega\boldsymbol\omega+\mathbf a_\omega^{\rm res},
\end{align}
where $b(T_c)=\max(0,c_0+c_1T_c+c_2T_c^2)$ and
$\mathbf e_R=\tfrac12(R_d^\top R-R^\top R_d)^\vee$.
$R_d$ is reconstructed from the commanded attitude after the simulator-interface sign conversion. Thrust coefficients and diagonal attitude-response gains are identified on nominal training flights. This is a kinematic and fitted low-level command-response backbone, not a rotor-resolved aerodynamic model. The tested outer-loop controller supplies attitude/throttle commands; the simulator's inner-loop response is represented by this backbone plus the learned residual.

For a logged transition of duration $\delta t_i=t_{i+1}-t_i$, the derivative components used for supervision are
\begin{equation}
D_v(i)=\frac{\mathbf v_{i+1}-\mathbf v_i}{\delta t_i},\qquad
D_\omega(i)=\frac{\boldsymbol\omega_{i+1}-\boldsymbol\omega_i}{\delta t_i}.
\end{equation}
The command $\mathbf u_i$ belongs to this same interval. Terminal rows are never input anchors or residual targets; their recorded state may close the last completed interval used for local derivative supervision. Multi-step targets, in contrast, exclude terminal endpoints and interpolation pairs touching them. No derivative computed from future measurements is supplied as a forecast input.
'''

TRAIN_BOUNDARY=r'''
\paragraph{Training access versus deployment access}
The deployment algorithm requires an executable controller and its restorable memory, but no controller gradient. The multi-step optimization used here has a stronger development-time requirement: analytical development controllers are mirrored in a differentiable implementation, and gradients propagate through their predicted-state feedback and adaptation updates to the residual model. Controller parameters themselves are not optimized. Numerical forward parity with the original implementations is checked; parity does not imply gradient-free training. A controller available only as an opaque executable can still be tested after model fitting, but this particular refinement procedure cannot be claimed to train through an arbitrary opaque controller. Transfer evaluation uses the frozen dynamics and the original neural-adaptive controller, without a differentiable neural-controller replica.

\paragraph{Rollout procedure}
At each anchor: (i) copy the measured state, observed history, and controller snapshot independently for every member; (ii) query each controller copy using its predicted state and the known reference; (iii) refresh the residual when a model-update instant is reached, otherwise hold it; (iv) integrate one control interval and append predicted state--command samples at model-update instants; and (v) repeat to the horizon before aggregating trajectory margins and endpoint spread. Real future actions, measurements, and disturbances are never substituted into the recursion. Quaternion states are renormalized after integration.
'''

CALIBRATION=r'''
Specifically, $C_H(s)=\operatorname{sigmoid}(a_H(s-\mu_H)/d_H+b_H)$, where $a_H\geq0$ and the location and scale are fitted on calibration scores. The slope and intercept minimize episode-balanced binary cross-entropy with slope regularization: each calibration episode has equal total weight. A disjoint calibration subset sets the warning threshold from negative examples to target the false-positive budget. Calibration is controller-specific; transferring a frozen dynamics model therefore does not imply calibration-free transfer.

For $n$ position-calibration episodes, let $r_i$ be the largest normalized endpoint error among all evaluated anchors in episode $i$. The scale is the ordered value $q_{H,c}=r_{(\lceil(n+1)c\rceil)}$; if this rank exceeds $n$, the scale is infinite. This finite-sample convention targets joint coverage of the specified endpoint collection under exchangeable episode blocks. Matched scenario designs and distribution shifts limit that interpretation, so empirical block coverage is reported rather than a universal safety guarantee. An endpoint set does not cover all intervening states.
'''

SETUP=r'''\subsection{Implementation and Hyperparameter Rationale}
\label{subsec:hyperparameters}
The blind input has 17 components (13 state variables and four attitude/throttle commands). Each member uses one GRU layer with 64 hidden units and a $64\rightarrow64\rightarrow6$ output head with SiLU activation. Its output is deterministic residual acceleration; probability is introduced through empirical calibration, not a sampled wind model. The ensemble comprises three independently initialized members trained on the same episodes, without episode-bootstrap training. This cost-conscious size is compared with a single member, not presented as globally optimal.

The controller and RK4 interval are $\Delta_c=0.01$~s, matching the native controller, while $\Delta_m=0.05$~s reduces neural evaluations without skipping feedback updates. The principal window therefore spans 100 control updates and 20 residual updates. History duration $T_h=0.5$~s gives 11 samples including the anchor. A development-only warm-start comparison of 0.25, 0.5, and 1~s across three initializations selected this duration by the lowest mean validation position RMSE averaged over the two examined forecast horizons. It is a limited candidate comparison rather than an optimal-memory claim.

One-step fitting uses 30 epochs, batch size 256, AdamW learning rate $10^{-3}$, weight decay $10^{-5}$, and gradient norm clipping at 5. Input and residual normalization use training data only; the checkpoint minimizes validation residual loss. Initial closed-loop refinement uses three epochs at $10^{-4}$ and batch size 32. Final refinement compares $3\times10^{-5}$ with $10^{-4}$ for up to three additional epochs, retaining the former by mean member validation loss. Epoch zero remains eligible. The training window is 2~s (40 model-update targets), exposing recursion beyond the principal evaluation horizon. Weights are $(\lambda_p,\lambda_v,\lambda_q,\lambda_\omega,\lambda_{\rm res})=(1,1,1,0.1,0.05)$, with scales 0.6~m, 1~m/s, $\sin(15^\circ)$, and 1~rad/s; the residual uses its training normalization. These fixed weights prioritize trajectory geometry while retaining local residual consistency. They are not independently optimized. Checked forward discrepancies between the differentiable and original development-controller rollouts are below $1.4\times10^{-5}$ in maximum absolute state coordinates on the parity cases, not a uniform error bound.

Safety requirements are $e_{\max}=0.60$~m and $\alpha_{\max}=30^\circ$, applied to all testers. They specify this test envelope rather than universal flight limits. Calibration uses slope penalty $10^{-3}$ and a common negative-anchor FPR budget of 0.05. Position coverage levels 0.90 and 0.95 expose width--coverage trade-offs; a 0.02-m spread floor prevents near-zero normalization. These are fixed design settings, whereas history, learning rate, and checkpoints use development validation only. Calibration and confirmation never select model weights.

AirSim uses the SimpleFlight vehicle with simulator clock scale one. The latency results were obtained with sequential CPU execution, one PyTorch thread, and preloaded models on Windows 10 (Intel Family 6, Model 167, Stepping 1). The archived benchmark does not record a marketing CPU name or full software build versions, so these timings are implementation diagnostics rather than hardware-independent real-time guarantees.

'''

def manuscript():
    s=read(ROOT/'supplementary_statistics.json');assets(s)
    body=(SOURCE/'three_controller_body.tex').read_text(encoding='utf-8')
    body=body.replace('The testing interface requires executable controller access and snapshot/restore capability, but no controller gradients or learned surrogate of its control law.','At deployment, the testing interface requires executable controller access and snapshot/restore capability, but no controller gradients or learned surrogate of its control law.')
    body=body.replace('Independent initialization and episode-level bootstrap training provide distinct fitted dynamics hypotheses.','Independent initialization on the same training episodes provides distinct fitted dynamics hypotheses; no episode bootstrap is used to train the evaluated ensemble.')
    body=body.replace('Terminal samples and incomplete transitions are excluded from target construction.','Terminal rows cannot serve as supervised anchors; multi-step target windows must remain strictly within a valid episode.')
    body=body.replace(r'\subsection{Controller-in-the-Loop Training and Rollout}',MATH+'\n'+r'\subsection{Controller-in-the-Loop Training and Rollout}')
    body=body.replace(r'\subsection{Safety Probability and Ensemble Uncertainty}',TRAIN_BOUNDARY+'\n'+r'\subsection{Safety Probability and Ensemble Uncertainty}')
    body=body.replace(r'\section{Experimental Evaluation}',CALIBRATION+'\n'+r'\section{Experimental Evaluation}')
    a=body.index(r'\subsection{Implementation and Hyperparameter Rationale}');b=body.index(r'\subsection{Ablations, Baselines, and Metrics}',a);body=body[:a]+SETUP+body[b:]
    body=body.replace('including the restored Geometric comparison.','with no confirmation labels used for fitting.')
    body=body.replace('Geometric and Adaptive data are used for world-model development; NN-Adaptive evaluates transfer.','Geometric and Adaptive data are used for world-model development; NN-Adaptive evaluates frozen-dynamics transfer with separate target-controller calibration, not calibration-free zero-shot transfer.')
    insert=r'''
Table~\ref{tab:partitions} accounts for the analysis corpus. The actuator is fitted using two nominal flights already included in the training partition. The exploratory development partition was previously available during scenario development and is not an independent confirmation set. An additional eight 12-s NN-controller screening flights (1.6 min total) select controller settings on development scenarios only; they do not train the world model. The listed main corpus has 420 flights (420 min nominal duration), plus those eight screening flights, rather than 180 training flights. Calibration and confirmation reuse scenario families but not episodes or seeds. The same environmental realizations are paired across controllers; statistical evidence is conditional on this limited randomization.
\input{data_partitions}
'''
    body=body.replace(r'Table~\ref{tab:controllers} summarizes',insert+'\n'+r'Table~\ref{tab:controllers} summarizes')
    table('data_partitions.tex',r'Data accounting. G/A/NN denote the three tested controllers. Durations are nominal simulated flight minutes; each listed flight lasts 60 s. Parameter selection uses development validation, not confirmation.','tab:partitions','Partition & Controllers & Flights & Minutes & Role',[
        ['Training','G/A','40','40','Model fitting'],['Validation','G/A','40','40','Model selection'],['Exploratory','G/A','40','40','Earlier diagnostics'],['Calibration fit','G/A/NN','60','60','Probability mapping'],['Calibration threshold','G/A/NN','60','60','Warning threshold'],['Confirmation','G/A/NN','180','180','Frozen-model evaluation']],'llrrl')
    body=body.replace('This is a controller-specific ablation, not an all-controller ablation claim.',r'''This is a controller-specific ablation. Additional retrospective ablations compare a current-state-only GRU with the historical GRU under the same one-step objective, three initializations, 30-epoch budget, training/validation episodes, and architecture. A one-sample GRU is effectively memoryless across samples. Both deploy through identical sliding-window semantics; the historical one-step checkpoints are also compared with the final multi-step ensemble. Each new variant receives its own probability and threshold calibration using the original disjoint calibration subsets. No main-model checkpoint or test threshold is changed after inspecting these additional results.''')
    old='The classifier predicts labels directly, while dynamics testers also expose physical trajectories.'
    new=r'''These are controlled representatives of model-based and predictive-monitoring approaches, not reproductions of all cited systems. Physics isolates the nominal backbone; Latest residual holds the latest completed-transition residual; EMA holds a causally filtered residual with 0.1-s time constant over the preceding 0.5 s. All three retain controller feedback. Reactive uses the current physical margin and Trend linearly extrapolates its nonnegative worsening slope from recent history. Direct Safety GRU represents direct temporal risk forecasting, motivated by predictive monitoring~\cite{sharifi2025monitoring}, but is not claimed to reproduce that work. It has one 64-unit GRU layer and a $64\rightarrow64\rightarrow3$ SiLU head for the three originally evaluated horizons, trained with weighted binary cross-entropy, batch 256, AdamW at $5\times10^{-4}$, and up to 30 epochs across three initializations. Validation selects its checkpoint; training-derived positive weights are capped at 20. Unlike dynamics testers, it outputs no physical trajectory. Scenario-search systems such as Aerialist~\cite{khatiri2024aerialist} generate test inputs and address a different task, so are contextual related work rather than forecast baselines.'''
    body=body.replace(old,new)
    body=body.replace('NN paired intervals resample matched episodes and are conditional on the limited randomization used here.',r'''Paired differences versus Latest residual use 5,000 bootstrap resamples of whole episodes, retaining all correlated anchors within each block. These unadjusted descriptive 95\% intervals are conditional on the scenario corpus and are not independent random-seed trials. AUPRC is interpreted alongside positive-label prevalence.''')
    body=body.replace(r'\section{Results and Discussion}',r'''Event analysis uses the existing once-per-second anchors, not an assumed 100-Hz warning stream. A violation event is a contiguous run of unsafe recorded states, without merging gaps. Onsets in the observed interval are eligible if a currently safe anchor occurs within the preceding prediction window; an alarm is assigned only to the first subsequent onset in its window. Event recall uses eligible onsets, with all onsets also reported. Lead time is the interval from the earliest qualifying positive anchor to onset. False-alarm runs group consecutive false-positive anchors and are counted per 56 observed seconds per flight. Subtracting the controller-specific median rollout cost provides only a diagnostic timing proxy, excluding communication and scheduling. Reliability diagrams use ten equal-width probability bins; disagreement diagnostics relate endpoint spread to actual error and stratify coverage by disturbance metadata.

\section{Results and Discussion}''')
    loc=r'\input{ablation_table}'
    body=body.replace(loc,loc+r'''

\paragraph{History information and multi-step refinement}
Table~\ref{tab:training_ablations} tests two further design choices. Under one-step training, including history reduces position RMSE from 0.1172 to 0.1073~m; the paired difference is $-0.0099$~m with 95\% interval $[-0.0161,-0.0038]$~m. This supports the value of temporal context within the matched architecture and budget, not identification of true wind. Closed-loop refinement further reduces RMSE to 0.1046~m, a modest $-0.0027$~m change with interval $[-0.0033,-0.0020]$~m. It also reduces FPR, but recall and AUPRC do not improve uniformly. Thus the multi-step objective improves trajectory fidelity without establishing an across-metric warning advantage. The comparison measures the full refinement pipeline, including checkpoint selection, rather than an isolated optimization step.
\input{training_ablations}
''')
    body=body.replace('The evidence supports a joint short-horizon prediction-and-warning advantage. It does not establish superiority for every metric or a horizon-independent ranking; Appendix~\\ref{app:horizon} documents the longer-horizon sensitivity.',r'''Table~\ref{tab:paired} quantifies differences against the strong Latest residual baseline. NN-Adaptive point estimates favor CIL in RMSE, Brier, recall, and FPR, but only the FPR interval excludes zero. Its RMSE difference is $-0.0101$~m with interval $[-0.0380,0.0204]$~m; consequently this comparison does not establish a statistically resolved trajectory improvement on this controller. Geometric shows resolved RMSE and Brier reductions, while Adaptive's RMSE interval narrowly includes zero. FPR intervals favor CIL for all three controllers at the separately calibrated operating points. The evidence supports a joint prediction-and-warning capability with favorable point estimates, not universal or horizon-independent dominance.
\input{paired_statistics}''')
    body=body.replace('The question is no longer whether an ensemble outperforms one member, which RQ1 addresses, but what a warning means and when it can be useful. We examine','We examine')
    body=body.replace('This is pre-violation evidence in replay, not a demonstrated 1-s intervention lead time or a lead-time distribution. Its 0.19-s interval must be assessed alongside inference latency.','This local example illustrates the mechanism; the following event analysis assesses its timing across the full confirmation corpus.')
    target=r'\paragraph{Coverage and spatial resolution}'
    eventtext=r'''\paragraph{Event-level warning evidence}
Table~\ref{tab:events} summarizes full-corpus event accounting. Eligible-event recall is 0.953/0.974/0.923 for Geometric/Adaptive/NN-Adaptive, with median detected-event leads 0.497/0.498/0.420~s. These figures are conditional on an available safe anchor: 36/37/34 additional onsets are ineligible at the recorded schedule. False-alarm runs occur at 0.61/0.95/1.29 per observed minute. Thus high anchor-level recall does not eliminate operational alarm burden.
\input{event_statistics}

\paragraph{Information carried by uncertainty}
Table~\ref{tab:reliability} and Fig.~\ref{fig:reliability_events} assess information beyond coverage. Spread--error Spearman correlations are 0.577/0.571/0.536; endpoint RMSE increases monotonically across spread quartiles. On NN-Adaptive it grows from 0.057~m in the lowest quartile to 0.174~m in the highest. Ensemble disagreement therefore identifies relatively difficult predictions in this corpus, although it is not a complete disturbance posterior. Probability ECE is 0.068/0.067/0.053; the reliability curves reveal remaining mismatch rather than perfect calibration. These are descriptive held-out diagnostics, not additional tuning objectives.
\input{reliability_statistics}
\begin{figure*}[tbp]
\centering
\includegraphics[width=\textwidth]{reliability_events.pdf}
\caption{Held-out reliability and warning timing of the proposed method. (a) Probability-bin reliability; the dotted diagonal denotes ideal agreement. (b) Position error by ensemble-spread quartile. (c) Detected-event lead-time distributions. (d) The same intervals after subtracting a controller-specific median rollout-cost proxy; negative values indicate that this cost alone exceeds the recorded lead. Timing is retrospective at a 1-Hz anchor schedule, not measured end-to-end intervention performance.}
\label{fig:reliability_events}
\end{figure*}
\FloatBarrier

'''
    body=body.replace(target,eventtext+target)
    body=body.replace('Endpoint sets also do not certify the intervening trajectory.',r'''Endpoint sets also do not certify the intervening trajectory. Table~\ref{tab:strata} separates wind regimes and ground-effect cases under the same global calibration, exposing heterogeneous spatial resolution rather than hiding it behind pooled coverage.
\input{uncertainty_strata}''')
    body=body.replace('They are also material compared with the illustrative 0.19-s crossing interval.',r'''Deducting these median costs from detected-event leads leaves median timing proxies of 0.380/0.380/0.286~s; 87.2\%/86.5\%/88.5\% of detected events retain a positive interval. These conditional fractions are upper estimates of practical timing availability because communication, snapshot reconstruction, scheduling, and actuation are omitted.''')
    body=body.replace('upper estimates of practical timing availability','optimistic diagnostic proxies for practical timing availability')
    body=body.replace('Thus its benefit is a more accurate trajectory with fewer missed violations and false alarms at that operating point, not uniformly better ranking:', 'These point estimates jointly favor trajectory accuracy and warning performance at that operating point, but not ranking:')
    body=body.replace('exposing heterogeneous spatial resolution rather than hiding it behind pooled coverage.', 'exposing heterogeneous spatial resolution. In particular, gust-only episode coverage falls to 0.778 for Adaptive and 0.889 for NN-Adaptive (nine flights each), despite high aggregate coverage; global calibration does not ensure conditional coverage in every disturbance subgroup.')
    body=body.replace('Broader environments, event-level lead time, end-to-end latency, and physical-flight transfer remain to be evaluated.','The event-level evidence is retrospective and schedule-dependent; end-to-end latency, successful intervention, broader environments, and physical-flight transfer remain to be evaluated. Additional training ablations and uncertainty diagnostics are retrospective extensions on the same confirmation corpus, not a newly collected independent replication.')
    body=body.replace('Future work should establish event-level warning utility under end-to-end timing constraints and validate transfer to physical flight and broader disturbance distributions.','Future work should validate the measured retrospective warning intervals under end-to-end timing constraints and test transfer to physical flight and broader disturbance distributions.')
    body=body.replace('\\FloatBarrier\n\n\\subsection{Validity and Scope}', '\\subsection{Validity and Scope}')
    body=body.replace('\\end{figure*}\n\\FloatBarrier\n\n\\paragraph', '\\end{figure*}\n\n\\paragraph')
    body=body.replace('Geometric/Adaptive/NN-Adaptive','Geometric, Adaptive, and NN-Adaptive, respectively')
    body=body.replace('0.953/0.974/0.923','0.953, 0.974, and 0.923')
    write('three_controller_body.tex',body)
    main=(SOURCE/'main.tex').read_text(encoding='utf-8')
    main=main.replace('Our use is fundamentally different:','In the present testing setting,')
    main=main.replace('and remain independent of the internal implementation of the controller under test.','and separate deployment-time executable access from the stronger controller access used during model development.')
    main=main.replace('Its responses depend','Its responses depend')
    main=main.replace('Purely data-driven latent dynamics may therefore be unsuitable','Purely data-driven latent dynamics require additional physical-state decoding and validation')
    main=main.replace('This demonstrates that system-level violations can be anticipated before they occur.','This establishes predictive monitoring as a relevant predecessor to the present work.')
    main=main.replace('AirSim experiments under wind, gusts, and ground effect demonstrate improved short-horizon prediction accuracy and a favorable balance between violation detection and false alarms relative to the evaluated alternatives.','AirSim experiments under wind, gusts, and ground effect support a joint advantage in short-horizon trajectory prediction and calibrated warning operating points, while paired analyses delimit which improvements are statistically resolved.')
    main=main.replace('Ablation studies support the importance of future control feedback and controller-memory preservation, while reliability analysis identifies practical limits.','Ablations support temporal context, recursive training, future feedback, and controller-memory preservation; event-level and uncertainty analyses quantify warning usefulness and its practical limits.')
    main=main.replace(r'\begin{document}',r'''\renewcommand{\topfraction}{0.9}
\renewcommand{\bottomfraction}{0.8}
\renewcommand{\textfraction}{0.08}
\renewcommand{\floatpagefraction}{0.75}
\setcounter{topnumber}{3}
\setcounter{totalnumber}{5}
\hypersetup{hidelinks}
\makeatletter
\let\ps@pprintTitle\ps@plain
\makeatother
\begin{document}''')
    write('main.tex',main)
    # Unify emphasis: only comparative performance tables bold numeric best values.
    for name in ['latency_table.tex','controller_table.tex','uncertainty_table.tex','single_uncertainty_table.tex','ours_extended_sets.tex','ours_extended_table.tex']:
        t=(SOURCE/name).read_text(encoding='utf-8');t=re.sub(r'\\textbf\{([^{}]*)\}',r'\1',t)
        t=t.replace('Bold ratios emphasize the ensemble cost, not a performance advantage.','Ratios report the additional runtime cost.')
        t=re.sub(r'Bold[^.]*\.', '', t)
        if name=='latency_table.tex':t=t.replace('\\resizebox{\\textwidth}{!}{%\n','').replace('\\end{tabular}}','\\end{tabular}')
        write(name,t)
    for name in ['ablation_table.tex','geometric_v2_table.tex','adaptive_v2_table.tex','nn_adaptive_v2_table.tex']:
        t=(SOURCE/name).read_text(encoding='utf-8').replace(r'\textbf{Ours: CIL world model}','Ours: CIL world model');write(name,t)
    write('REVISION_NOTES.md','''# Submission revision

Preserves original conceptual figures and all original numerical comparisons.
Adds current-state and one-step ensemble ablations, 5,000 paired episode bootstrap intervals,
event onset accounting, reliability diagrams, spread-error diagnostics and disturbance-stratified sets.
Corrects development-time differentiable controller access versus deployment black-box interface.
Corrects ensemble provenance: same episodes, different initialization; no training bootstrap.
Clarifies local derivative endpoint use versus multi-step terminal exclusion.
All new analyses are retrospective; no original predictor, threshold, or collected flight is changed.
No AirSim calls or additional flight collection were made.

Evidence: artifacts/submission_revision_20260917; builders: submission_evidence.py, submission_paper.py.
Existing author/affiliation placeholders and administrative submission declarations remain for author completion.
The existing benchmark did not archive a marketing CPU name or exact software versions; the paper states this limitation.
''')
    print('Submission manuscript and new evidence figures built.',flush=True)

if __name__=='__main__':manuscript()
