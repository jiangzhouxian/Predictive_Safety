"""Read frozen flights; supplementary retrospective analyses, no AirSim calls."""
import argparse
import json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from scipy.stats import spearmanr
from .final_study import probability, risk, fit_probability, block_quantile
from .metrics import select_threshold_fpr, average_precision_grouped
from .episode import load_episode, latest_index_at_or_before

ROOT=Path('artifacts/submission_revision_20260917')
OLD=Path('artifacts/final_study_20260915')
NN=Path('artifacts/nn_controller_study_20260915')
KINDS=['geometric_v2','adaptive_v2','nn_adaptive_v2']
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(d,indent=2,allow_nan=False),encoding='utf-8')
def data(folder,kind):
    out=[]
    for p in sorted(Path(folder).glob('*.npz')):
        with np.load(p,allow_pickle=False) as z:
            if str(z['controller'])==kind:out.append(dict(z))
    return out
def sources(kind):
    base=NN/'evaluation' if kind==KINDS[-1] else OLD
    calpath=(base/'calibration.json' if kind==KINDS[-1] else
             NN/'adaptive_recalibration.json' if kind==KINDS[1] else
             Path('artifacts/three_controller_paper_20260916/geometric_calibration.json'))
    return data(base/'confirmation_predictions',kind),read(calpath)
def metrics(blocks,inds):
    a=np.sum([blocks[i] for i in inds],axis=0)
    # squared position error/count, squared probability error/count, TP/P, FP/N
    return np.array([np.sqrt(a[0]/a[1]),a[2]/a[3],a[4]/a[5],a[6]/a[7]])
def block(d,cal,m,name):
    y=d['y'][d['safe'],1];p=probability(d['score'][m,d['safe'],1],cal['probability'][name+'|1.0'])
    alarm=p>=cal['thresholds'][name+'|1.0']['threshold']
    return [float(d['pos_sq'][m,:,1].sum()),len(d['safe']),float(((p-y)**2).sum()),len(y),int((alarm&(y==1)).sum()),int(y.sum()),int((alarm&(y==0)).sum()),int((y==0).sum())]

def analyze():
    report=read('artifacts/three_controller_paper_20260916/report.json')
    latency=read('artifacts/three_controller_paper_20260916/latency.json')
    result={'protocol':{'horizon_s':1,'anchor_period_s':1,'bootstrap_repeats':5000,'bootstrap_seed':170917,
        'scope':'Retrospective supplementary analysis; fixed original predictions/calibration; no test tuning.',
        'events':'Contiguous unsafe log samples, no gap merging. Eligible onset in [2,58] with at least one currently safe evaluated anchor in preceding 1 s. An alarm is associated only with the first subsequent onset in its window.',
        'false_alarm':'Start of a consecutive run of false-positive safe anchors; rate per observed 56 s per flight.',
        'latency':'Existing controller-specific median microbenchmark subtracted; not measured end-to-end latency.'},'controllers':{}}
    for kind in KINDS:
        ds,cal=sources(kind);pathmap={Path(p).stem:p for p in report['flights'][kind]['paths']}
        ours=[block(d,cal,3,'world_model') for d in ds];base=[block(d,cal,1,'latest') for d in ds]
        point=metrics(ours,range(len(ds)))-metrics(base,range(len(ds)))
        rng=np.random.default_rng(170917);boot=[]
        for _ in range(5000):
            ids=rng.integers(0,len(ds),len(ds));boot.append(metrics(ours,ids)-metrics(base,ids))
        ci=np.quantile(boot,[.025,.975],axis=0)
        paired={n:{'difference':float(point[i]),'CI95':ci[:,i].tolist()} for i,n in enumerate(['RMSE_m','Brier','Recall','FPR'])}
        bins=[[] for _ in range(10)];allp=[];ally=[];spread=[];errors=[];groups={};leads=[];eventrows=[]
        delay=next(r['median_ms']/1000 for r in latency['rows'] if r['controller']==kind and r['members']==3 and r['horizon_s']==1)
        for d in ds:
            ep=load_episode(pathmap[str(d['episode'])]);ai=[latest_index_at_or_before(ep.t,t) for t in np.arange(2.,58.)];at=ep.t[ai]
            p=probability(d['score'][3,:,1],cal['probability']['world_model|1.0']);y=d['y'][:,1];alarm=(p>=cal['thresholds']['world_model|1.0']['threshold'])&d['safe']
            allp.extend(p[d['safe']].tolist());ally.extend(y[d['safe']].tolist())
            rr=risk(ep.x,ep.ref);unsafe=(rr>=0)&~ep.terminal
            onset=np.flatnonzero(unsafe & ~np.r_[False,unsafe[:-1]])
            ontime=ep.t[onset];ontime=ontime[(ontime>at[0])&(ontime<=at[-1]+1+1e-9)]
            valid=[];detected=[]
            for t in ontime:
                candidate=np.flatnonzero(d['safe']&(at<t-1e-10)&(at>=t-1-1e-10))
                # Avoid attributing one positive window to multiple flickering events.
                candidate=np.array([i for i in candidate if not np.any((ontime>at[i]+1e-10)&(ontime<t-1e-10))],dtype=int)
                if len(candidate):
                    valid.append(float(t));hits=candidate[alarm[candidate]]
                    if len(hits):detected.append(float(t-at[hits[0]]))
            false=alarm&(y==0);starts=false&~np.r_[False,false[:-1]]
            eventrows.append({'episode':str(d['episode']),'onsets':len(ontime),'eligible':len(valid),'detected':len(detected),'false_alarm_runs':int(starts.sum()),'lead_s':detected})
            leads+=detected
            e=np.sqrt(d['pos_sq'][3,:,1]);s=d['spread'][:,1];errors+=e.tolist();spread+=s.tolist()
            group='ground effect' if ep.meta.get('environment_effect',{}).get('kind','none')!='none' else str(ep.meta['disturbance']['kind'])
            q=cal['intervals']['1.0']['0.9'];radius=q*np.maximum(s,.02)
            groups.setdefault(group,[]).append({'episode_covered':bool(np.all(e<=radius)),'diameter':float(2*radius.mean()),'rmse':float(np.sqrt((e**2).mean()))})
        allp=np.array(allp);ally=np.array(ally);reliability=[]
        for j in range(10):
            mask=(allp>=j/10)&(allp<((j+1)/10) if j<9 else allp<=1)
            if mask.any():reliability.append({'n':int(mask.sum()),'mean_p':float(allp[mask].mean()),'rate':float(ally[mask].mean())})
        sp=np.asarray(spread);err=np.asarray(errors);quart=[]
        # Rank bins avoid coincident spread quantile boundaries.
        for ids in np.array_split(np.argsort(sp,kind='stable'),4):quart.append({'n':len(ids),'spread':float(sp[ids].mean()),'rmse':float(np.sqrt(np.mean(err[ids]**2)))})
        eligible=sum(r['eligible'] for r in eventrows);det=sum(r['detected'] for r in eventrows)
        result['controllers'][kind]={'paired_latest':paired,'anchors':len(ally),'positives':int(ally.sum()),'prevalence':float(ally.mean()),
            'reliability':reliability,'ECE':float(sum(b['n']*abs(b['mean_p']-b['rate']) for b in reliability)/len(ally)),
            'spread_error_spearman':float(spearmanr(sp,err).statistic),'spread_quartiles':quart,
            'strata':{g:{'episodes':len(v),'episode_coverage':float(np.mean([r['episode_covered'] for r in v])),'diameter_m':float(np.mean([r['diameter'] for r in v])),'RMSE_m':float(np.sqrt(np.mean([r['rmse']**2 for r in v])))} for g,v in groups.items()},
            'events':{'total_onsets':sum(r['onsets'] for r in eventrows),'eligible':eligible,'detected':det,'recall':det/eligible if eligible else None,'lead_quantiles_s':np.quantile(leads,[.1,.5,.9]).tolist() if leads else [],
                'latency_proxy_s':delay,'positive_remaining_fraction':float(np.mean(np.array(leads)>delay)) if leads else None,'remaining_median_s':float(np.median(leads)-delay) if leads else None,
                'false_runs_per_minute':sum(r['false_alarm_runs'] for r in eventrows)/(len(ds)*56/60),'records':eventrows}}
        print(kind,paired,result['controllers'][kind]['events']['lead_quantiles_s'],flush=True)
    save(ROOT/'supplementary_statistics.json',result)

def train_instant():
    import torch
    from .training import build_dataset,train_member
    from .actuator import load_actuator
    torch.set_num_threads(1)
    paths=read('artifacts/development_study_20260910/protocol.json')['paths'];act='artifacts/development_study_20260910/actuator.json'
    train=build_dataset(paths['40'],load_actuator(act));val=build_dataset(paths['41'],load_actuator(act))
    train=(train[0][:,-1:],train[1],train[2]);val=(val[0][:,-1:],val[1],val[2])
    save(ROOT/'ablation_protocol.json',{'scope':'Retrospective ablation; all existing NN calibration and confirmation episodes retained. No tuning on these results.',
        'current_state':'Same architecture, seeds, targets, no episode bootstrap (matches original development training), 30 epochs, batch 256, AdamW 1e-3; one sample per window; selected by development validation loss.',
        'one_step':'Original one-step checkpoints with matched sliding-window deployment; no closed-loop refinement.',
        'comparison':'Current-state versus history under one-step training isolates history. One-step history versus frozen final model measures full refinement pipeline, not a single optimizer step.'})
    for seed in [7000,7001,7002]:
        p=ROOT/f'instant_matched_{seed}.pt'
        if not p.exists():train_member(paths['40'],act,p,seed=seed,epochs=30,history_s=0.,bootstrap=False,val_paths=paths['41'],train_data=train,val_data=val)

def predict_ablation_job(args):
    import torch
    from .actuator import load_actuator
    from .rollout import ResidualRuntime,deterministic_trace
    from .controller import make_controller
    from .references import reference_at
    from .multistep_training import interpolate_states
    path,out=args;torch.set_num_threads(1);ep=load_episode(path)
    actuator=load_actuator('artifacts/development_study_20260910/actuator.json')
    variants=[[ROOT/f'instant_matched_{s}.pt' for s in [7000,7001,7002]],
        [Path(f'artifacts/advantage_study_20260911/repeat_{s}/window_only.pt') for s in [7000,7001,7002]]]
    runtimes=[[ResidualRuntime(p) for p in v] for v in variants]
    anchors=[latest_index_at_or_before(ep.t,t) for t in np.arange(2.,58.)];ctrl=make_controller(ep.meta['controller']);ctrl.reset();snap={}
    for i in range(max(anchors)+1):
        if i in anchors:snap[i]=ctrl.snapshot()
        ctrl.step(ep.x[i],reference_at(ep.meta['reference'],ep.t[i]),.01 if i==0 else ep.t[i]-ep.t[i-1])
    score=np.zeros((2,len(anchors)));sq=score.copy()
    for i,a in enumerate(anchors):
        refs=np.stack([reference_at(ep.meta['reference'],ep.t[a]+k*.01).as_vector() for k in range(1,101)])
        truth=interpolate_states(ep,[ep.t[a]+1])[0]
        for j,rs in enumerate(runtimes):
            traces=np.stack([deterministic_trace(ep,a,1.,actuator,r,controller_snapshot=snap[a])[1][1:] for r in rs])
            score[j,i]=risk(traces,refs[None]).max(-1).mean();sq[j,i]=np.sum((traces[:,-1,:3].mean(0)-truth[:3])**2)
    np.savez_compressed(out,score=score,pos_sq=sq,episode=np.array(Path(path).stem))
    return str(out)

def predict_ablations():
    paths=sorted((NN/'flights').glob('[56]*/*.npz'));jobs=[]
    folder=ROOT/'ablation_predictions';folder.mkdir(parents=True,exist_ok=True)
    for p in paths:
        out=folder/p.name
        if not out.exists():jobs.append((str(p),str(out)))
    with ProcessPoolExecutor(max_workers=6) as ex:
        futures=[ex.submit(predict_ablation_job,j) for j in jobs]
        for i,f in enumerate(as_completed(futures),1):print(f'new ablation {i}/{len(jobs)} {f.result()}',flush=True)
    cal=data(NN/'evaluation/calibration_predictions',KINDS[-1]);test,_=sources(KINDS[-1]);rows=[]
    for m,name in enumerate(['Current-state / one-step','History / one-step']):
        load=lambda d:dict(np.load(folder/(str(d['episode'])+'.npz'),allow_pickle=False))
        fit=[d for d in cal if int(d['seed'])==50];tune=[d for d in cal if int(d['seed'])==51]
        s=np.concatenate([load(d)['score'][m,d['safe']] for d in fit]);y=np.concatenate([d['y'][d['safe'],1] for d in fit]);ids=np.concatenate([np.repeat(i,d['safe'].sum()) for i,d in enumerate(fit)])
        params=fit_probability(s,y,ids);ss=np.concatenate([load(d)['score'][m,d['safe']] for d in tune]);yy=np.concatenate([d['y'][d['safe'],1] for d in tune]);threshold,_=select_threshold_fpr(yy,probability(ss,params),.05)
        s=np.concatenate([load(d)['score'][m,d['safe']] for d in test]);y=np.concatenate([d['y'][d['safe'],1] for d in test]);p=probability(s,params);a=p>=threshold
        rows.append({'name':name,'RMSE_m':float(np.sqrt(np.mean([load(d)['pos_sq'][m].mean() for d in test]))),'AP':average_precision_grouped(y,s),'Brier':float(np.mean((p-y)**2)),'Recall':float(a[y==1].mean()),'FPR':float(a[y==0].mean()),'calibration':params,'threshold':float(threshold)})
    save(ROOT/'training_ablations.json',rows)
    # Paired endpoint uncertainty; each episode remains an indivisible block.
    vectors=[np.array([load(d)['pos_sq'][i].mean() for d in test]) for i in (0,1)]
    vectors.append(np.array([d['pos_sq'][3,:,1].mean() for d in test]))
    paired=[];rng=np.random.default_rng(170918)
    for a,b,label in [(1,0,'history_one_step_minus_current_state'),(2,1,'final_minus_history_one_step')]:
        differences=[]
        for _ in range(5000):
            ids=rng.integers(0,len(test),len(test));differences.append(float(np.sqrt(vectors[a][ids].mean())-np.sqrt(vectors[b][ids].mean())))
        paired.append({'comparison':label,'difference_m':float(np.sqrt(vectors[a].mean())-np.sqrt(vectors[b].mean())),'CI95_m':np.quantile(differences,[.025,.975]).tolist()})
    save(ROOT/'training_ablation_intervals.json',paired);print(rows,paired,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['analyze','ablations']);a=p.parse_args()
    if a.phase=='analyze':analyze()
    else:train_instant();predict_ablations()
