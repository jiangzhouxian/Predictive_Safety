"""Independent consistency checks for manuscript evidence and split manifests."""
from pathlib import Path
import numpy as np
from .submission_evidence import ROOT,read,save,sources,block,metrics,KINDS
from .episode import load_episode

def main():
    original=read('artifacts/three_controller_paper_20260916/report.json')
    stats=read(ROOT/'supplementary_statistics.json');checks=[]
    for kind in KINDS:
        ds,cal=sources(kind)
        assert len(ds)==60
        assert len({str(d['episode']) for d in ds})==60
        for method,index in [('world_model',3),('latest',1)]:
            actual=metrics([block(d,cal,index,method) for d in ds],range(60))
            row=next(r for r in original['prediction'][kind] if r['method']==method and r['horizon_s']==1)
            expected=np.array([row['position_RMSE_m'],row['Brier'],row['recall'],row['fpr']])
            assert np.allclose(actual,expected,atol=1e-12),(kind,method,actual,expected)
        event=stats['controllers'][kind]['events']
        assert event['detected']<=event['eligible']<=event['total_onsets']
        assert all(0<t<=1+1e-8 for r in event['records'] for t in r['lead_s'])
        assert sum(g['episodes'] for g in stats['controllers'][kind]['strata'].values())==60
        checks.append(kind+': frozen metrics reproduced, 60 complete flights, event and stratum counts valid')
    dev=read('artifacts/development_study_20260910/protocol.json')['paths']
    final=read('artifacts/final_study_20260915/protocol.json')['paths']
    sets=[{str(Path(p).resolve()) for p in dev[k]} for k in ['40','41','42']]
    sets += [{str(Path(p).resolve()) for p in final[k]} for k in ['calibration','confirmation']]
    sets += [{str(p.resolve()) for p in Path('artifacts/nn_controller_study_20260915/flights').glob(s+'/*.npz')} for s in ['50','51','60','61','62']]
    assert all(not a&b for i,a in enumerate(sets) for b in sets[i+1:])
    assert sum(map(len,sets))==420
    durations=[float(load_episode(p).meta['duration_requested_s']) for ss in sets for p in ss]
    assert np.allclose(durations,60)
    checks.append('420 distinct main-corpus files; 420 nominal simulated minutes; pairwise-disjoint file partitions')
    # Additional variants use exactly all calibration and confirmation NN flights.
    files=list((ROOT/'ablation_predictions').glob('*.npz'));assert len(files)==100
    for p in files:
        with np.load(p,allow_pickle=False) as z:
            assert z['score'].shape==(2,56) and z['pos_sq'].shape==(2,56)
            assert np.isfinite(z['score']).all() and np.isfinite(z['pos_sq']).all()
    checks.append('100 new ablation predictions finite and complete: 40 calibration + 60 confirmation')
    for name in ['fig1.png','framework_overview.png']:
        assert (Path('paper_revision_20260917_theory/figures')/name).read_bytes()==(Path('paper_revision_20260917_submission/figures')/name).read_bytes()
    checks.append('Both original conceptual figures byte-identical')
    save(ROOT/'audit.json',{'passed':True,'checks':checks});print('\n'.join(checks))

if __name__=='__main__':main()
